import { Client, handle_file } from '@gradio/client';
export const config = { maxDuration: 60 };
export default async function handler(req,res){
  if(req.method!=='POST') return res.status(405).json({error:'Gunakan POST'});
  try{
    const {image,scale='2'}=req.body||{};
    if(!['2','4','8'].includes(String(scale))) return res.status(400).json({error:'Skala tidak valid'});
    if(typeof image!=='string'||!/^data:image\/(png|jpeg|webp);base64,/.test(image)||image.length>3_800_000) return res.status(413).json({error:'Unggah JPG/PNG/WebP di bawah 2,7 MB'});
    const b=Buffer.from(image.split(',')[1],'base64');
    const client=await Client.connect('Nick088/Real-ESRGAN_Pytorch',process.env.HF_TOKEN?{hf_token:process.env.HF_TOKEN}:{});
    const result=await client.predict('/predict',{img:handle_file(b),size_modifier:String(scale)});
    const output=result?.data?.[0];
    const url=typeof output==='string'?output:(output?.url||output?.path);
    if(!url||!/^https?:\/\//.test(url))throw Error('Space tidak mengembalikan URL hasil publik');
    return res.status(200).json({url});
  }catch(err){return res.status(502).json({error:'Pemrosesan Hugging Face gagal',detail:String(err?.message||err).slice(0,350)});}
}
