import { Client, handle_file } from '@gradio/client';
export const config = { maxDuration: 60 };
export default async function handler(req,res){
  if(req.method!=='POST')return res.status(405).json({error:'Gunakan POST'});
  try{
    const {video,scale='2'}=req.body||{};
    if(!['2','4','8'].includes(String(scale)))return res.status(400).json({error:'Skala tidak valid'});
    if(typeof video!=='string'||!/^data:video\/[\w.+-]+;base64,/.test(video)||video.length>3_500_000)return res.status(413).json({error:'Video terlalu besar. Coba video sangat pendek di bawah 2,5 MB.'});
    const buffer=Buffer.from(video.split(',')[1],'base64');
    const client=await Client.connect('Nick088/Real-ESRGAN_Pytorch',process.env.HF_TOKEN?{hf_token:process.env.HF_TOKEN}:{});
    const result=await client.predict('/predict_1',{video_filepath:handle_file(buffer),size_modifier:String(scale)});
    const output=result?.data?.[0];
    const url=typeof output==='string'?output:(output?.url||output?.path);
    if(!url||!/^https?:\/\//.test(url))throw Error('Space tidak mengembalikan URL video hasil');
    return res.status(200).json({url});
  }catch(err){return res.status(502).json({error:'AI Video belum berhasil',detail:String(err?.message||err).slice(0,350)});}
}
